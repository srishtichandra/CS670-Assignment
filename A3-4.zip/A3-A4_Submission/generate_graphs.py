#!/usr/bin/env python3
"""
generate_graphs.py

Scans the `runs/` directory for run folders named like `run_m{m}_n{n}_k{k}_q{q}`.
For each run it computes the mean user/item update times by reading
`user_update_time_s_p*.csv` and `item_update_time_s_p*.csv` files and
creates summary plots saved into `runs/plots/`.

Usage:
    python3 generate_graphs.py --runs runs --outdir runs/plots

"""
import argparse
import re
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

RUN_DIR_PATTERN = re.compile(r'run_m(\d+)_n(\d+)_k(\d+)_q(\d+)')


def collect_run_means(run_path: Path):
    """Return (item_mean, user_mean) for the run or (None, None) if missing."""
    item_means = []
    user_means = []
    for f in run_path.glob('item_update_time_s_p*.csv'):
        try:
            df = pd.read_csv(f, comment='#')
            if 'item_update_time_s' in df.columns:
                item_means.append(df['item_update_time_s'].mean())
            else:
                # try second column fallback
                item_means.append(df.iloc[:,1].mean())
        except Exception as e:
            print(f"Warning: could not read {f}: {e}")
    for f in run_path.glob('user_update_time_s_p*.csv'):
        try:
            df = pd.read_csv(f, comment='#')
            if 'user_update_time_s' in df.columns:
                user_means.append(df['user_update_time_s'].mean())
            else:
                user_means.append(df.iloc[:,1].mean())
        except Exception as e:
            print(f"Warning: could not read {f}: {e}")
    item_mean = float(np.mean(item_means)) if item_means else None
    user_mean = float(np.mean(user_means)) if user_means else None
    return item_mean, user_mean


def main(runs_dir: str, out_dir: str):
    root = Path(runs_dir)
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)

    runs = []
    if not root.exists():
        print(f"Runs directory {root} does not exist. Nothing to plot.")
        return

    for rd in sorted(root.iterdir()):
        if not rd.is_dir():
            continue
        m = n = k = q = None
        mobj = RUN_DIR_PATTERN.search(rd.name)
        if mobj:
            m, n, k, q = mobj.groups()
        else:
            # try parse numbers inside name
            pals = re.findall(r'(\d+)', rd.name)
            if len(pals) >= 4:
                m, n, k, q = pals[:4]
        item_mean, user_mean = collect_run_means(rd)
        runs.append({'run_dir': rd.name, 'path': str(rd), 'm': m, 'n': n, 'k': k, 'q': q,
                     'item_mean_s': item_mean, 'user_mean_s': user_mean})

    df = pd.DataFrame(runs)
    if df.empty:
        print('No runs found.')
        return

    # Save CSV of summary
    summary_csv = out / 'runs_summary.csv'
    df.to_csv(summary_csv, index=False)
    print(f'Wrote summary CSV to {summary_csv}')

    # Summary bar chart
    df_plot = df.copy()
    df_plot['label'] = df_plot['run_dir']
    df_plot = df_plot.fillna(0)

    fig, ax = plt.subplots(figsize=(max(6, len(df_plot)*1.2), 5))
    x = range(len(df_plot))
    width = 0.35
    user_vals = df_plot['user_mean_s'].tolist()
    item_vals = df_plot['item_mean_s'].tolist()
    ax.bar([xi - width/2 for xi in x], user_vals, width, label='user update (s)')
    ax.bar([xi + width/2 for xi in x], item_vals, width, label='item update (s)')
    ax.set_xticks(list(x))
    ax.set_xticklabels(df_plot['label'].tolist(), rotation=45, ha='right')
    ax.set_ylabel('Mean time per query (s)')
    ax.set_title('Mean user vs item update time across runs')
    ax.legend()
    plt.tight_layout()
    summary_png = out / 'summary_timings.png'
    fig.savefig(summary_png)
    plt.close(fig)
    print(f'Wrote summary plot to {summary_png}')

    # Group by (m,n,k) and plot mean vs q
    df2 = df.dropna(subset=['q'])
    if df2.empty:
        print('No runs with q parsed. Skipping per-parameter plots.')
        return
    df2['q'] = df2['q'].astype(int)
    grouped = df2.groupby(['m','n','k'])
    for gkey, gdf in grouped:
        gm, gn, gk = gkey
        gdf_sorted = gdf.sort_values('q')
        qs = gdf_sorted['q'].astype(int).tolist()
        user_means = gdf_sorted['user_mean_s'].tolist()
        item_means = gdf_sorted['item_mean_s'].tolist()
        fig, ax = plt.subplots(figsize=(8,5))
        ax.plot(qs, user_means, marker='o', label='user update (s)', color='#1f77b4')
        ax.plot(qs, item_means, marker='s', label='item update (s)', color='#d62728')
        ax.set_xscale('log')
        ax.set_xlabel('q (number of queries)')
        ax.set_ylabel('Mean time per query (s)')
        ax.set_title(f'Mean update times vs q — m={gm} n={gn} k={gk}')
        ax.grid(True, linestyle='--', alpha=0.5)
        ax.legend()
        plt.tight_layout()
        out_png = out / f'm{gm}_n{gn}_k{gk}_mean_vs_q.png'
        fig.savefig(out_png)
        plt.close(fig)
        print(f'Wrote plot {out_png}')

    # Scatter user vs item mean
    fig, ax = plt.subplots(figsize=(6,6))
    ax.scatter(df2['user_mean_s'], df2['item_mean_s'], s=60, alpha=0.8)
    for _, row in df2.iterrows():
        label = f"m={row['m']} n={row['n']} k={row['k']} q={row['q']}"
        ax.annotate(label, (row['user_mean_s'], row['item_mean_s']), fontsize=8, alpha=0.8)
    ax.set_xlabel('user mean (s)')
    ax.set_ylabel('item mean (s)')
    ax.set_title('User vs Item mean update times across runs')
    plt.tight_layout()
    scatter_png = out / 'user_vs_item_scatter.png'
    fig.savefig(scatter_png)
    plt.close(fig)
    print(f'Wrote scatter plot to {scatter_png}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--runs', default='runs', help='directory containing run_*/ folders')
    parser.add_argument('--outdir', default='runs/plots', help='directory to write plots into')
    args = parser.parse_args()
    main(args.runs, args.outdir)
