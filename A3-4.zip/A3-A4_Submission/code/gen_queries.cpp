#include "common.hpp"
#include <random>
#include <iomanip>
#include <fstream>

class QueryGenerator {
private:
    Config config;
    matrix_t U, V;  // U: m×k (users×features), V: n×k (items×features)
    vector<Query> queries;
    // Per-party DPF keys: [query][feature]
    vector<vector<DpfKey>> p0_dpf_keys;
    vector<vector<DpfKey>> p1_dpf_keys;
    
public:
    QueryGenerator(const Config& cfg) : config(cfg), U(cfg.m, vector<share_t>(cfg.k)), V(cfg.n, vector<share_t>(cfg.k)) {
        // RNG is now initialized globally
    }
    
    void generate_matrices() {
        // Generate matrix U (users × features) with reasonable values
        for(int i = 0; i < config.m; i++) {
            for(int d = 0; d < config.k; d++) {
                U[i][d] = rng() % MAX_VALUE;  // Keep values reasonable
            }
        }
        
        // Generate matrix V (items × features) with reasonable values
        for(int j = 0; j < config.n; j++) {
            for(int d = 0; d < config.k; d++) {
                V[j][d] = rng() % MAX_VALUE;  // Keep values reasonable
            }
        }
    }
    
    void generate_queries() {
        queries.clear();
        queries.reserve(config.q);
        p0_dpf_keys.assign(config.q, vector<DpfKey>(config.k));
        p1_dpf_keys.assign(config.q, vector<DpfKey>(config.k));
        
        for(int query_idx = 0; query_idx < config.q; query_idx++) {
            Query q(config.n);  // Initialize with size
            
            // Random user and item indices
            q.i = rng() % config.m;  // user index
            q.j = rng() % config.n;  // item index (private)
            
            // NOTE: We no longer create or share a one-hot vector for j.
            // Instead we generate a pair of DPF keys (one per party) for each
            // feature dimension here and store them for serialization.
            for (int d = 0; d < config.k; ++d) {
                auto keys = DPF::generateDPF(config.n, q.j, 0ULL, rng);
                p0_dpf_keys[query_idx][d] = std::move(keys.first);
                p1_dpf_keys[query_idx][d] = std::move(keys.second);
            }
            
            queries.push_back(q);
        }
    }
    
    void save_shares_to_files(const vector<matrix_t>& U_shares, 
                             const vector<matrix_t>& V_shares) {
        // Save P0 and P1 shares to files
        for(int party = 0; party < 2; party++) {
            string prefix = "p" + to_string(party);
            
            // Save U shares
            ofstream u_file(prefix + "_u_shares.txt");
            u_file << "# U shares for P" << party << endl;
            u_file << config.m << " " << config.k << endl;
            for(int i = 0; i < config.m; i++) {
                for(int d = 0; d < config.k; d++) {
                    u_file << U_shares[party][i][d];
                    if(d < config.k-1) u_file << " ";
                }
                u_file << endl;
            }
            u_file.close();
            
            // Save V shares
            ofstream v_file(prefix + "_v_shares.txt");
            v_file << "# V shares for P" << party << endl;
            v_file << config.n << " " << config.k << endl;
            for(int j = 0; j < config.n; j++) {
                for(int d = 0; d < config.k; d++) {
                    v_file << V_shares[party][j][d];
                    if(d < config.k-1) v_file << " ";
                }
                v_file << endl;
            }
            v_file.close();
            
            // NOTE: One-hot J shares are replaced by DPF keys. We write
            // per-party DPF keys into a consolidated file below.
        }
        
        // Save query metadata
        ofstream meta_file("query_metadata.txt");
        meta_file << "# Query metadata" << endl;
        meta_file << "# Format: query_id user_id item_j" << endl;
        meta_file << config.q << endl;
        for(int q = 0; q < config.q; q++) {
            meta_file << q << " " << queries[q].i << " " << queries[q].j << endl;
        }
        meta_file.close();

        // Save DPF keys for P0 and P1. We write two files: p0_dpf_keys.txt
        // and p1_dpf_keys.txt. Each file contains config.q * config.k keys in
        // row-major order (query, feature). Format per key:
        // size root_seed correction_count cw0 cw1 ... final_word
        ofstream p0_dpf("p0_dpf_keys.txt");
        ofstream p1_dpf("p1_dpf_keys.txt");
        p0_dpf << config.q << " " << config.k << " " << config.n << endl;
        p1_dpf << config.q << " " << config.k << " " << config.n << endl;

        auto write_key = [&](ofstream &out, const DpfKey &k) {
            out << k.size << " " << k.root_seed << " " << k.correction_words.size();
            for (auto &cw : k.correction_words) out << " " << cw;
            out << " " << k.final_word << "\n";
        };

        for (int qidx = 0; qidx < config.q; ++qidx) {
            for (int d = 0; d < config.k; ++d) {
                write_key(p0_dpf, p0_dpf_keys[qidx][d]);
                write_key(p1_dpf, p1_dpf_keys[qidx][d]);
            }
        }
        p0_dpf.close(); p1_dpf.close();
    }
    
    void print_shares_and_metadata() {
        // Print configuration
        cout << "=== CONFIGURATION ===" << endl;
        cout << "m=" << config.m << " n=" << config.n << " k=" << config.k << " q=" << config.q << endl;
        cout << "Ring: Z_{2^" << RING_BITS << "} (size=" << RING_SIZE_64 << ")" << endl;
        cout << endl;
        
        // Generate secret shares
    vector<matrix_t> U_shares(2, matrix_t(config.m, vector<share_t>(config.k)));
    vector<matrix_t> V_shares(2, matrix_t(config.n, vector<share_t>(config.k)));
        
        // Create U shares
        for(int i = 0; i < config.m; i++) {
            for(int d = 0; d < config.k; d++) {
                share_t u0 = rng() % RING_SIZE_64;
                share_t u1 = (U[i][d] - u0) % RING_SIZE_64;
                U_shares[0][i][d] = u0;
                U_shares[1][i][d] = u1;
            }
        }
        
        // Create V shares  
        for(int j = 0; j < config.n; j++) {
            for(int d = 0; d < config.k; d++) {
                share_t v0 = rng() % RING_SIZE_64;
                share_t v1 = (V[j][d] - v0) % RING_SIZE_64;
                V_shares[0][j][d] = v0;
                V_shares[1][j][d] = v1;
            }
        }
        
        // One-hot J shares removed: item selection is done via DPF keys.
        
        // Print shares for debugging as required by assignment
    cout << "=== P0 SHARES ===" << endl;
    print_party_shares(0, U_shares[0], V_shares[0]);
        
    cout << "=== P1 SHARES ===" << endl;
    print_party_shares(1, U_shares[1], V_shares[1]);
        
    // Save shares to files for MPC protocol (DPF keys written inside)
    save_shares_to_files(U_shares, V_shares);
        
    cout << "=== RECONSTRUCTED VALUES (for debugging only) ===" << endl;
    print_reconstructed_values(U_shares, V_shares);
        
        cout << "=== QUERY METADATA ===" << endl;
        for(int q = 0; q < config.q; q++) {
            cout << "Query " << q << ": User " << queries[q].i << " -> Item " << queries[q].j << endl;
        }
        cout << endl;
    }
    
private:
    void print_party_shares(int party_id, const matrix_t& u_shares, const matrix_t& v_shares) {
        cout << "U shares (P" << party_id << "):" << endl;
        for(int i = 0; i < config.m; i++) {
            cout << "  User " << i << ": ";
            for(int d = 0; d < config.k; d++) {
                cout << u_shares[i][d];
                if(d < config.k-1) cout << " ";
            }
            cout << endl;
        }
        
        cout << "V shares (P" << party_id << "):" << endl;
        for(int j = 0; j < config.n; j++) {
            cout << "  Item " << j << ": ";
            for(int d = 0; d < config.k; d++) {
                cout << v_shares[j][d];
                if(d < config.k-1) cout << " ";
            }
            cout << endl;
        }
        
        cout << endl;
    }
    
    void print_reconstructed_values(const vector<matrix_t>& U_shares, 
                                   const vector<matrix_t>& V_shares) {
        cout << "Original U matrix:" << endl;
        for(int i = 0; i < config.m; i++) {
            cout << "  User " << i << ": ";
            for(int d = 0; d < config.k; d++) {
                share_t reconstructed = (U_shares[0][i][d] + U_shares[1][i][d]) % RING_SIZE_64;
                cout << reconstructed;
                if(d < config.k-1) cout << " ";
            }
            cout << endl;
        }
        
        cout << "Original V matrix:" << endl;
        for(int j = 0; j < config.n; j++) {
            cout << "  Item " << j << ": ";
            for(int d = 0; d < config.k; d++) {
                share_t reconstructed = (V_shares[0][j][d] + V_shares[1][j][d]) % RING_SIZE_64;
                cout << reconstructed;
                if(d < config.k-1) cout << " ";
            }
            cout << endl;
        }
        
        cout << endl;
    }

    // Inline secret sharing function
    pair<share_t, share_t> share_secret(share_t secret) {
        share_t share0 = rng() % RING_SIZE_64;
        share_t share1 = (secret - share0) % RING_SIZE_64;
        return make_pair(share0, share1);
    }
};

// Global RNG
mt19937 rng;

int main(int argc, char* argv[]) {
    if(argc != 5) {
        cerr << "Usage: " << argv[0] << " <m> <n> <k> <q>" << endl;
        cerr << "  m: number of users" << endl;
        cerr << "  n: number of items" << endl;  
        cerr << "  k: feature dimension" << endl;
        cerr << "  q: number of queries" << endl;
        return 1;
    }
    
    Config config;
    config.m = stoi(argv[1]);
    config.n = stoi(argv[2]);
    config.k = stoi(argv[3]);
    config.q = stoi(argv[4]);
    
    // Write configuration to file for pB to read
    ofstream config_file("mpc_config.txt");
    config_file << config.m << " " << config.n << " " << config.k << " " << config.q << endl;
    config_file.close();
    
    // Initialize RNG with fixed seed for reproducibility
    rng.seed(42);
    
    QueryGenerator generator(config);
    generator.generate_matrices();
    generator.generate_queries();
    generator.print_shares_and_metadata();
    
    return 0;
}