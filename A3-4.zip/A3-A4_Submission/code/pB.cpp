#include "common.hpp"
#include <thread>
#include <chrono>

// Helper to load a matrix of shares from a file
void load_matrix_shares(const string& filename, matrix_t& matrix, int rows) {
    ifstream file(filename);
    string line;
    getline(file, line); getline(file, line); // Skip headers
    matrix.resize(rows);
    for (int i = 0; i < rows; ++i) {
        getline(file, line);
        istringstream iss(line);
        share_t val;
        while (iss >> val) matrix[i].push_back(val);
    }
}

// Simulate communication by writing differences to a file
void exchange_diffs(const string& filename, const vector<vector<share_t>>& diffs) {
    ofstream out(filename);
    for (const auto& row : diffs) {
        for (size_t i = 0; i < row.size(); ++i) {
            out << row[i] << (i == row.size() - 1 ? "" : " ");
        }
        out << endl;
    }
}

// Simulate receiving data by reading from a file
void wait_and_reconstruct_diffs(const string& filename, vector<vector<share_t>>& our_diffs) {
    while (!ifstream(filename).good()) {
        this_thread::sleep_for(chrono::milliseconds(20));
    }
    ifstream in(filename);
    string line;
    int row_idx = 0;
    while (getline(in, line)) {
        istringstream iss(line);
        share_t val;
        int col_idx = 0;
        while (iss >> val) {
            our_diffs[row_idx][col_idx] += val; // Reconstruct by adding shares
            col_idx++;
        }
        row_idx++;
    }
}

// Secure Multiplication of a secret scalar [x] and secret vector [y]
// Returns shares of [x*y]
vector<share_t> secure_scalar_vec_mult(share_t x_share, const vector<share_t>& y_share,
                                       share_t a_share, const vector<share_t>& b_share,
                                       const vector<share_t>& c_share,
                                       int party_id, int k, const string& comm_prefix) {
    // 1. Compute differences locally
    share_t d = x_share - a_share;
    vector<share_t> e = y_share;
    for (int i = 0; i < k; ++i) e[i] -= b_share[i];

    // 2. Exchange and reconstruct
    string fname = comm_prefix + to_string(party_id) + ".txt";
    string other_fname = comm_prefix + to_string(1 - party_id) + ".txt";
    vector<vector<share_t>> diffs = {{d}, e};
    exchange_diffs(fname, diffs);
    wait_and_reconstruct_diffs(other_fname, diffs);
    share_t D = diffs[0][0];
    vector<share_t> E = diffs[1];

    // 3. Compute final shares
    vector<share_t> z_share = c_share;
    for (int i = 0; i < k; ++i) {
        z_share[i] += a_share * E[i];
        z_share[i] += D * b_share[i];
        // CORRECTED: Only one party (P0) adds the public cross-term
        if (party_id == 0) {
            z_share[i] += D * E[i];
        }
    }
    return z_share;
}

// Secure Dot Product of two secret vectors [x] and [y]
// Returns a share of [x·y]
share_t secure_dot_product(const vector<share_t>& x_share, const vector<share_t>& y_share,
                           const vector<share_t>& a_share, const vector<share_t>& b_share,
                           share_t c_share, int party_id, int k, const string& comm_prefix) {
    // 1. Compute differences locally
    vector<share_t> d = x_share, e = y_share;
    for(int i=0; i<k; ++i) d[i] -= a_share[i];
    for(int i=0; i<k; ++i) e[i] -= b_share[i];

    // 2. Exchange and reconstruct
    string fname = comm_prefix + to_string(party_id) + ".txt";
    string other_fname = comm_prefix + to_string(1 - party_id) + ".txt";
    vector<vector<share_t>> diffs = {d, e};
    exchange_diffs(fname, diffs);
    wait_and_reconstruct_diffs(other_fname, diffs);
    vector<share_t> D = diffs[0], E = diffs[1];

    // 3. Compute final share
    share_t z_share = c_share;
    uint64_t cross_term = 0;
    for(int i=0; i<k; ++i) {
        z_share += a_share[i] * E[i];
        z_share += D[i] * b_share[i];
        cross_term += (uint64_t)D[i] * E[i];
    }
    // CORRECTED: Only one party (P0) adds the public cross-term
    if (party_id == 0) {
        z_share += cross_term;
    }
    return z_share;
}


int main(int argc, char* argv[]) {
    if (argc != 6) {
        cerr << "Usage: " << argv[0] << " <party_id> <m> <n> <k> <q>" << endl;
        return 1;
    }

    Config config;
    config.party_id = stoi(argv[1]);
    config.m = stoi(argv[2]);
    config.n = stoi(argv[3]);
    config.k = stoi(argv[4]);
    config.q = stoi(argv[5]);
    
    // --- LOAD ALL DATA ---
    cout << "P" << config.party_id << ": Loading data..." << endl;
    string prefix = "p" + to_string(config.party_id);
    
    matrix_t u_shares, v_shares;
    load_matrix_shares(prefix + "_u_shares.txt", u_shares, config.m);
    load_matrix_shares(prefix + "_v_shares.txt", v_shares, config.n);

    // Load per-party DPF keys: file contains config.q * config.k keys in
    // row-major order (query, feature). Each key serialized as:
    // size root_seed correction_count cw0 cw1 ... final_word
    vector<vector<DpfKey>> dpf_keys; // [q][k]
    auto load_dpf_keys = [&](const string &fname) {
        ifstream in(fname);
        if(!in.good()) {
            cerr << "Warning: DPF key file " << fname << " not found.\n";
            return;
        }
        int qfile=0, kfile=0, nfile=0;
        in >> qfile >> kfile >> nfile;
        dpf_keys.assign(qfile, vector<DpfKey>(kfile));
        for (int qi = 0; qi < qfile; ++qi) {
            for (int ki = 0; ki < kfile; ++ki) {
                DpfKey key;
                size_t cw_count = 0;
                in >> key.size >> key.root_seed >> cw_count;
                key.correction_words.resize(cw_count);
                for (size_t c = 0; c < cw_count; ++c) in >> key.correction_words[c];
                in >> key.final_word;
                dpf_keys[qi][ki] = std::move(key);
            }
        }
    };
    load_dpf_keys(prefix + "_dpf_keys.txt");

    matrix_t sv_a(config.n + config.q), sv_b(config.n + config.q), sv_c(config.n + config.q);
    ifstream sv_file(prefix + "_scalar_vector_triples.txt");
    string line;
    getline(sv_file, line); getline(sv_file, line); getline(sv_file, line);
    for(int i=0; i<(config.n + config.q); ++i) {
        sv_a[i].resize(1); sv_b[i].resize(config.k); sv_c[i].resize(config.k);
        sv_file >> sv_a[i][0];
        for(int l=0; l<config.k; ++l) sv_file >> sv_b[i][l];
        for(int l=0; l<config.k; ++l) sv_file >> sv_c[i][l];
    }

    vector<share_t> dot_a, dot_b;
    share_t dot_c;
    ifstream dot_file(prefix + "_dot_triple.txt");
    getline(dot_file, line); getline(dot_file, line);
    dot_a.resize(config.k); dot_b.resize(config.k);
    for(int l=0; l<config.k; ++l) dot_file >> dot_a[l];
    for(int l=0; l<config.k; ++l) dot_file >> dot_b[l];
    dot_file >> dot_c;
    
    vector<QueryMetadata> queries(config.q);
    ifstream meta_file("query_metadata.txt");
    getline(meta_file, line); getline(meta_file, line); getline(meta_file, line);
    for(int i=0; i<config.q; ++i) {
        meta_file >> queries[i].query_id >> queries[i].user_id >> queries[i].item_j;
    }
    
    cout << "P" << config.party_id << ": Starting online protocol..." << endl;

    // --- ONLINE PROTOCOL ---
    for (int i = 0; i < config.q; ++i) {
        cout << "\nP" << config.party_id << ": --- Query " << i << " ---" << endl;
        int user_idx = queries[i].user_id;

        // Selection NO LONGER uses one-hot shares. We instead use the public
        // metadata item index for computing the dot-product s for now
        // (this keeps behavior consistent with earlier version while DPF
        // updates are applied to V below). The secure DPF-based item update
        // will update V using the pre-generated DPF keys.
        vector<share_t> v_j_share(config.k, 0);
        int item_idx = queries[i].item_j; // from metadata
        for (int l = 0; l < config.k; ++l) {
            v_j_share[l] = v_shares[item_idx][l];
        }

        // 2. Secure Dot Product: Compute share of s = <u_i, v_j>
        // Time the user-profile update (dot + scalar-vector mult + local add)
        auto tu0 = chrono::high_resolution_clock::now();
        string comm_dot_prefix = "comm_dot_q" + to_string(i) + "_p";
        share_t s_share = secure_dot_product(u_shares[user_idx], v_j_share,
            dot_a, dot_b, dot_c, config.party_id, config.k, comm_dot_prefix);

        // 3. Secure Update: Compute u_i <- u_i + (1-s) * v_j
        share_t delta_share = (config.party_id == 0) ? (1 - s_share) : (0 - s_share);

        string comm_update_prefix = "comm_update_q" + to_string(i) + "_p";
        // Use dedicated Beaver triple for update (n+i to avoid conflict with selection)
        int update_triple_idx = config.n + i;
        vector<share_t> update_term = secure_scalar_vec_mult(delta_share, v_j_share,
            sv_a[update_triple_idx][0], sv_b[update_triple_idx], sv_c[update_triple_idx], config.party_id, config.k, comm_update_prefix);

        for (int l = 0; l < config.k; ++l) {
            u_shares[user_idx][l] += update_term[l];
        }
        auto tu1 = chrono::high_resolution_clock::now();
        chrono::duration<double> user_elapsed = tu1 - tu0;
        double user_update_time_s = user_elapsed.count();
        // Append timing to CSV (create header if needed)
        string user_timing_file = "user_update_time_s_p" + to_string(config.party_id) + ".csv";
        bool need_user_header = !ifstream(user_timing_file).good();
        ofstream utf(user_timing_file, ios::app);
        if (need_user_header) utf << "query_id,user_update_time_s\n";
        utf << i << "," << user_update_time_s << "\n";
        utf.close();
        cout << "P" << config.party_id << ": Query " << i << " processed." << endl;

        // --- DPF-based Item Profile Update (per Assignment 3) ---
        // We compute M_b (already computed as update_term) and then for each
        // feature exchange masked differences to reconstruct the new FCW_m,
        // create the updated key k', evaluate it to get XOR shares, convert
        // XOR->additive (insecure method), and add to V shares.
        if (dpf_keys.size() == (size_t)config.q) {
            // Time the item-update for this query
            auto t0 = chrono::high_resolution_clock::now();

            for (int f = 0; f < config.k; ++f) {
                // 3a. Get M_f share
                share_t M_f_share = update_term[f];

                // 3b. Load this party's DPF key for query i, feature f
                DpfKey mykey = dpf_keys[i][f];

                // 3c. Compute masked difference: diff_b = M_{b,f} - FCW_{b,f}
                share_t old_fcw_share = static_cast<share_t>(mykey.final_word % RING_SIZE_64);
                share_t masked_diff = (M_f_share + RING_SIZE_64 - old_fcw_share) % RING_SIZE_64;

                // 3d. Exchange masked_diff with the other party and reconstruct FCW_m
                string fname = "comm_fcw_q" + to_string(i) + "_f" + to_string(f) + "_p" + to_string(config.party_id) + ".txt";
                string other_fname = "comm_fcw_q" + to_string(i) + "_f" + to_string(f) + "_p" + to_string(1 - config.party_id) + ".txt";
                vector<vector<share_t>> diffs = {{masked_diff}};
                exchange_diffs(fname, diffs);
                wait_and_reconstruct_diffs(other_fname, diffs);
                share_t FCW_m = diffs[0][0];

                // 4. Create updated key k' by replacing final_word with FCW_m
                DpfKey kprime = mykey;
                kprime.final_word = static_cast<u64>(FCW_m);

                // 4b. Evaluate k' across the domain to get XOR shares
                // 4b. Evaluate k' across the domain to get XOR shares
                vector<share_t> my_delta_xor(config.n);
                for (int idx = 0; idx < config.n; ++idx) {
                    u64 v = DPF::evalDPF(kprime, idx);
                    my_delta_xor[idx] = static_cast<share_t>(v % RING_SIZE_64);
                }

                // Exchange XOR-share vectors with other party via files so we
                // can perform the simulated XOR->Additive conversion (as in
                // the provided Python reference). Write our vector then wait
                // for the other party's vector.
                string my_vec_file = "dpf_delta_q" + to_string(i) + "_f" + to_string(f) + "_p" + to_string(config.party_id) + ".txt";
                string other_vec_file = "dpf_delta_q" + to_string(i) + "_f" + to_string(f) + "_p" + to_string(1 - config.party_id) + ".txt";
                // Write my vector
                ofstream mv(my_vec_file);
                for (int idx = 0; idx < config.n; ++idx) {
                    mv << my_delta_xor[idx] << (idx + 1 == config.n ? "" : " ");
                }
                mv << "\n";
                mv.close();

                // Wait for other party's vector
                while (!ifstream(other_vec_file).good()) {
                    this_thread::sleep_for(chrono::milliseconds(10));
                }
                // Read other vector
                vector<share_t> other_delta_xor(config.n);
                ifstream ov(other_vec_file);
                for (int idx = 0; idx < config.n; ++idx) ov >> other_delta_xor[idx];
                ov.close();

                // Use the simulated conversion routine (requires both XOR shares)
                pair<vector<share_t>, vector<share_t>> Epair = xor_to_additive_conversion(
                    (config.party_id == 0) ? my_delta_xor : other_delta_xor,
                    (config.party_id == 0) ? other_delta_xor : my_delta_xor
                );

                vector<share_t> delta_add = (config.party_id == 0) ? Epair.first : Epair.second;

                // Apply update to V_shares: add per-item component for this feature
                for (int idx = 0; idx < config.n; ++idx) {
                    v_shares[idx][f] = (v_shares[idx][f] + delta_add[idx]) % RING_SIZE_64;
                }
            }

            // record elapsed time for item update (in seconds)
            auto t1 = chrono::high_resolution_clock::now();
            chrono::duration<double> elapsed = t1 - t0;
            double item_update_time_s = elapsed.count();

            // Append timing to CSV (create header if needed)
            string timing_file = "item_update_time_s_p" + to_string(config.party_id) + ".csv";
            bool need_header = !ifstream(timing_file).good();
            ofstream tf(timing_file, ios::app);
            if (need_header) tf << "query_id,item_update_time_s\n";
            tf << i << "," << item_update_time_s << "\n";
            tf.close();

        } else {
            cerr << "P" << config.party_id << ": No DPF keys loaded - skipping DPF update." << endl;
        }
    }

    // --- PRINT FINAL RESULTS ---
    cout << "\n=== P" << config.party_id << ": Final Updated U Shares ===" << endl;
    for (int i = 0; i < config.m; ++i) {
        cout << "User " << i << ": ";
        for (int d = 0; d < config.k; ++d) {
            cout << u_shares[i][d];
            if (d < config.k - 1) cout << " ";
        }
        cout << endl;
    }
    
    // --- DEBUGGING COMMUNICATION: P1 sends shares to P0 for reconstruction ---
    if (config.party_id == 1) {
        // P1 writes its final shares to a file for P0 to read
        cout << "\nP1: Sending final shares to P0 for debugging..." << endl;
        ofstream debug_file("debug_p1_final_shares.txt");
        for (int i = 0; i < config.m; ++i) {
            for (int d = 0; d < config.k; ++d) {
                debug_file << u_shares[i][d];
                if (d < config.k - 1) debug_file << " ";
            }
            debug_file << endl;
        }
        debug_file.close();
        cout << "P1: Final shares sent to P0." << endl;
    } else {
        // P0 waits for P1's shares and reconstructs for verification
        cout << "\nP0: Waiting for P1's final shares for debugging..." << endl;
        
        // Wait for P1's file
        while (!ifstream("debug_p1_final_shares.txt").good()) {
            this_thread::sleep_for(chrono::milliseconds(50));
        }
        
        // Read P1's shares
        matrix_t p1_final_shares;
        ifstream debug_file("debug_p1_final_shares.txt");
        string line;
        p1_final_shares.resize(config.m);
        for (int i = 0; i < config.m; ++i) {
            getline(debug_file, line);
            istringstream iss(line);
            share_t val;
            while (iss >> val) {
                p1_final_shares[i].push_back(val);
            }
        }
        debug_file.close();
        
        // Reconstruct and print final U matrix
        cout << "\n=== P0: RECONSTRUCTED FINAL U MATRIX (for debugging only) ===" << endl;
        for (int i = 0; i < config.m; ++i) {
            cout << "User " << i << ": ";
            for (int d = 0; d < config.k; ++d) {
                share_t p0_share = u_shares[i][d];
                share_t p1_share = p1_final_shares[i][d];
                uint64_t sum = (uint64_t)p0_share + (uint64_t)p1_share;
                share_t reconstructed = sum % RING_SIZE_64;
                cout << reconstructed;
                if (d < config.k - 1) cout << " ";
                // Debug: print the calculation
                cout << " [" << p0_share << "+" << p1_share << "=" << sum << " mod " << RING_SIZE_64 << "=" << reconstructed << "]";
            }
            cout << endl;
        }
        
        // Clean up debug file
        remove("debug_p1_final_shares.txt");
    }
    
    cout << "\n✅ P" << config.party_id << ": Protocol finished." << endl;

    return 0;
}