#include "common.hpp"

void generate_scalar_vector_triples(const Config& config) {
    // Generate n scalar×vector Beaver triples for oblivious selection
    // + q scalar×vector Beaver triples for updates
    int total_triples = config.n + config.q;
    ofstream p0_file("p0_scalar_vector_triples.txt");
    ofstream p1_file("p1_scalar_vector_triples.txt");
    
    // Headers
    p0_file << "Scalar×Vector Beaver Triples for P0" << endl;
    p0_file << "Format: scalar_a b_vector[k] c_vector[k]" << endl;
    p0_file << "Dimensions: total_triples=" << total_triples << " k=" << config.k << endl;
    
    p1_file << "Scalar×Vector Beaver Triples for P1" << endl;
    p1_file << "Format: scalar_a b_vector[k] c_vector[k]" << endl;
    p1_file << "Dimensions: total_triples=" << total_triples << " k=" << config.k << endl;
    
    mt19937 rng(42);  // Fixed seed for reproducibility
    uniform_int_distribution<share_t> dist(0, RING_SIZE_64 - 1);
    
    for(int i = 0; i < total_triples; i++) {
        // Generate random values
        share_t a = dist(rng);
        vector<share_t> b(config.k), c(config.k);
        
        for(int d = 0; d < config.k; d++) {
            b[d] = dist(rng);
            // c[d] = a * b[d] mod 2^RING_BITS
            c[d] = ((uint64_t)a * b[d]) % RING_SIZE_64;
        }
        
        // Generate secret shares
        share_t a0 = dist(rng);
        share_t a1 = (a - a0) % RING_SIZE_64;  // a = a0 + a1
        
        vector<share_t> b0(config.k), b1(config.k);
        vector<share_t> c0(config.k), c1(config.k);
        
        for(int d = 0; d < config.k; d++) {
            b0[d] = dist(rng);
            b1[d] = (b[d] - b0[d]) % RING_SIZE_64;  // b[d] = b0[d] + b1[d]
            
            c0[d] = dist(rng);
            c1[d] = (c[d] - c0[d]) % RING_SIZE_64;  // c[d] = c0[d] + c1[d]
        }
        
        // Write P0 shares
        p0_file << a0;
        for(int d = 0; d < config.k; d++) {
            p0_file << " " << b0[d];
        }
        for(int d = 0; d < config.k; d++) {
            p0_file << " " << c0[d];
        }
        p0_file << endl;
        
        // Write P1 shares
        p1_file << a1;
        for(int d = 0; d < config.k; d++) {
            p1_file << " " << b1[d];
        }
        for(int d = 0; d < config.k; d++) {
            p1_file << " " << c1[d];
        }
        p1_file << endl;
    }
    
    p0_file.close();
    p1_file.close();
}

void generate_dot_triple(const Config& config) {
    // Generate one dot product Beaver triple
    ofstream p0_file("p0_dot_triple.txt");
    ofstream p1_file("p1_dot_triple.txt");
    
    // Headers
    p0_file << "Dot Product Beaver Triple for P0" << endl;
    p0_file << "Format: a_vector[k] b_vector[k] c_scalar" << endl;
    p0_file << "Dimensions: k=" << config.k << endl;
    
    p1_file << "Dot Product Beaver Triple for P1" << endl;
    p1_file << "Format: a_vector[k] b_vector[k] c_scalar" << endl;
    p1_file << "Dimensions: k=" << config.k << endl;
    
    mt19937 rng(123);  // Different seed for dot product triple
    uniform_int_distribution<share_t> dist(0, RING_SIZE_64 - 1);
    
    // Generate random values
    vector<share_t> a(config.k), b(config.k);
    share_t c = 0;
    
    for(int d = 0; d < config.k; d++) {
        a[d] = dist(rng);
        b[d] = dist(rng);
        c += ((uint64_t)a[d] * b[d]) % RING_SIZE_64;
        c %= RING_SIZE_64;
    }
    
    // Generate secret shares
    vector<share_t> a0(config.k), a1(config.k);
    vector<share_t> b0(config.k), b1(config.k);
    
    for(int d = 0; d < config.k; d++) {
        a0[d] = dist(rng);
        a1[d] = (a[d] - a0[d]) % RING_SIZE_64;
        
        b0[d] = dist(rng);
        b1[d] = (b[d] - b0[d]) % RING_SIZE_64;
    }
    
    share_t c0 = dist(rng);
    share_t c1 = (c - c0) % RING_SIZE_64;
    
    // Write P0 shares
    for(int d = 0; d < config.k; d++) {
        p0_file << a0[d];
        if(d < config.k-1) p0_file << " ";
    }
    p0_file << endl;
    
    for(int d = 0; d < config.k; d++) {
        p0_file << b0[d];
        if(d < config.k-1) p0_file << " ";
    }
    p0_file << endl;
    
    p0_file << c0 << endl;
    
    // Write P1 shares
    for(int d = 0; d < config.k; d++) {
        p1_file << a1[d];
        if(d < config.k-1) p1_file << " ";
    }
    p1_file << endl;
    
    for(int d = 0; d < config.k; d++) {
        p1_file << b1[d];
        if(d < config.k-1) p1_file << " ";
    }
    p1_file << endl;
    
    p1_file << c1 << endl;
    
    p0_file.close();
    p1_file.close();
}

int main(int argc, char* argv[]) {
    if(argc != 5) {
        cout << "Usage: " << argv[0] << " <m> <n> <k> <q>" << endl;
        return 1;
    }
    
    Config config;
    config.m = atoi(argv[1]);
    config.n = atoi(argv[2]);
    config.k = atoi(argv[3]);
    config.q = atoi(argv[4]);
    
    cout << "=== Beaver Triple Generator ===" << endl;
    cout << "Parameters: m=" << config.m << ", n=" << config.n 
         << ", k=" << config.k << ", q=" << config.q << endl;
    
    cout << "Generating scalar×vector Beaver triples..." << endl;
    generate_scalar_vector_triples(config);
    
    cout << "Generating dot product Beaver triple..." << endl;
    generate_dot_triple(config);
    
    cout << "✅ Beaver triple generation complete!" << endl;
    cout << "Files created:" << endl;
    cout << "  - p0_scalar_vector_triples.txt, p1_scalar_vector_triples.txt" << endl;
    cout << "  - p0_dot_triple.txt, p1_dot_triple.txt" << endl;
    
    return 0;
}