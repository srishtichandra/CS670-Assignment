// common.cpp is left intentionally minimal: DPF primitives are defined
// inline in common.hpp. This translation unit exists to provide a single
// compilation unit that may be linked if needed.
#include "common.hpp"


