#pragma once

#include <vector>
#include <random>
#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <iomanip>
#include <cstdint>
#include <stdexcept>

using namespace std;

// Type definitions - using 16-bit for mod 2^16 arithmetic (smaller ring for easier verification)
using share_t = uint32_t;  // Still use uint32_t to avoid overflow during calculations
using matrix_t = vector<vector<share_t>>;

using u64 = uint64_t;

// Ring size for mod 2^16 arithmetic (much smaller for easier manual verification)
const int RING_BITS = 16;
const uint64_t RING_SIZE_64 = (1ULL << RING_BITS);  // 2^16 = 65536
const share_t MAX_VALUE = 1000;  // Keep values reasonable for smaller ring

// Query Metadata for verification
struct QueryMetadata {
    int query_id;
    int user_id;
    int item_j;
};

// Party roles (S0 and S1 as per assignment)
enum PartyRole {
    S0 = 0,
    S1 = 1
};

// 2-party secret share structure (for P0 and P1 only)
struct SecretShare {
    share_t share;
    int party_id;  // 0 or 1
};

// (One-hot vector removed — selection is now handled via DPF keys.)

// Beaver scalar×vector triple
struct BeaverScalarVector {
    share_t a_scalar;         // scalar share
    vector<share_t> b_vector; // vector share
    vector<share_t> c_vector; // c = a * b share
};

// Beaver dot-product triple  
struct BeaverDot {
    vector<share_t> a, b;     // vector shares
    share_t c;                // c = dot(a,b) share
};

// Query structure
struct Query {
    int i, j;  // user index i, item index j
    vector<share_t> u_i;      // shares of u_i vector
    // Item index j is recorded in metadata; selection uses DPF keys
    
    // NEW: DPF Keys for Item Update (one key per feature dimension)
    // For each query we store k DPF keys (one per feature). The generator
    // will produce a key pair (for P0 and P1) and save each party's key to
    // file. Here we keep the per-query, per-feature key for convenience.
    vector<struct DpfKey> dpf_keys;
    
    Query() : i(0), j(0) {}  // Default constructor
    Query(int size) : i(0), j(0) {}  // Constructor with size
};

// ---------------------- DPF declarations ----------------------
// We expose the compact DPF types and function prototypes here so other
// translation units (gen_queries, pB) can generate/evaluate DPF keys.
struct DpfKey {
    size_t size; // domain size
    u64 root_seed; // root seed with flag in LSB
    std::vector<u64> correction_words; // per-level correction words
    u64 final_word; // final correction word
};

// Inline DPF implementation moved into header so other translation units
// can use DPF primitives directly. Functions are placed inside namespace DPF
// and marked inline to allow inclusion in multiple TUs.
namespace DPF {
    inline void PRG(u64 seed, u64* out, size_t count) {
        std::mt19937_64 gen(seed);
        for (size_t i = 0; i < count; ++i) out[i] = gen();
    }

    namespace BitUtil {
        inline uint8_t LSB(u64 val) { return static_cast<uint8_t>(val & 1ULL); }
        inline u64 ClearLow2(u64 val) { return val & (~3ULL); }
        inline u64 SetLow2(u64 val, uint8_t b0, uint8_t b1) {
            return ClearLow2(val) | (static_cast<u64>(b0) & 1ULL) | ((static_cast<u64>(b1) & 1ULL) << 1);
        }
        inline uint8_t GetBit(u64 val, size_t bit_idx) { return static_cast<uint8_t>((val >> bit_idx) & 1ULL); }
        inline u64 XorIf(u64 s, u64 mask, bool condition) { return condition ? (s ^ mask) : s; }
    }

    inline size_t CalculateDepth(size_t n) {
        if (n <= 1) return n;
        size_t d = 0; size_t m = 1;
        while (m < n) { m <<= 1; ++d; }
        return d;
    }

    inline void Expand(u64 seed, u64 s_out[2], uint8_t t_out[2]) {
        PRG(seed, s_out, 2);
        t_out[0] = BitUtil::LSB(s_out[0]); s_out[0] = BitUtil::ClearLow2(s_out[0]);
        t_out[1] = BitUtil::LSB(s_out[1]); s_out[1] = BitUtil::ClearLow2(s_out[1]);
    }

    inline std::pair<DpfKey, DpfKey> generateDPF(size_t size, size_t location, u64 value, std::mt19937& rng) {
        if (location >= size) throw std::runtime_error("DPF location is out of range.");
        const size_t depth = CalculateDepth(size);
        u64 root_seed_A = rng(); u64 root_seed_B = rng();
        uint8_t t_A = BitUtil::LSB(root_seed_A); uint8_t t_B = t_A ^ 1;
        root_seed_B = BitUtil::ClearLow2(root_seed_B) | t_B;
        u64 s_A = BitUtil::ClearLow2(root_seed_A); u64 s_B = BitUtil::ClearLow2(root_seed_B);
        std::vector<u64> correction_words; correction_words.reserve(depth);
        for (size_t i = 0; i < depth; ++i) {
            const uint8_t path_bit = BitUtil::GetBit(location, depth - 1 - i);
            u64 s_A_children[2], s_B_children[2]; uint8_t t_A_children[2], t_B_children[2];
            Expand(s_A, s_A_children, t_A_children); Expand(s_B, s_B_children, t_B_children);
            const uint8_t keep = path_bit; const uint8_t lose = 1 - path_bit;
            u64 s_cw = s_A_children[lose] ^ s_B_children[lose];
            uint8_t t_cw[2]; t_cw[lose] = t_A_children[lose] ^ t_B_children[lose];
            t_cw[keep] = t_A_children[keep] ^ t_B_children[keep] ^ 1;
            s_A = BitUtil::XorIf(s_A_children[keep], s_cw, t_A);
            t_A = t_A_children[keep] ^ (t_cw[keep] & t_A);
            s_B = BitUtil::XorIf(s_B_children[keep], s_cw, t_B);
            t_B = t_B_children[keep] ^ (t_cw[keep] & t_B);
            u64 cw = BitUtil::SetLow2(s_cw, t_cw[0], t_cw[1]); correction_words.push_back(cw);
        }
        u64 final_A, final_B; PRG(s_A, &final_A, 1); PRG(s_B, &final_B, 1);
        u64 final_wc = value ^ final_A ^ final_B;
        DpfKey keyA{size, root_seed_A, correction_words, final_wc};
        DpfKey keyB{size, root_seed_B, correction_words, final_wc};
        return {std::move(keyA), std::move(keyB)};
    }

    inline u64 evalDPF(const DpfKey& key, size_t index) {
        if (index >= key.size) throw std::runtime_error("DPF index is out of range.");
        const size_t d = CalculateDepth(key.size);
        u64 s = BitUtil::ClearLow2(key.root_seed); uint8_t t = BitUtil::LSB(key.root_seed);
        for (size_t i = 0; i < d; ++i) {
            const u64& cw = key.correction_words[i]; const uint8_t path_bit = BitUtil::GetBit(index, d - 1 - i);
            u64 s_children[2]; uint8_t t_children[2]; Expand(s, s_children, t_children);
            u64 seed_mask = BitUtil::ClearLow2(cw); uint8_t t_cw0 = BitUtil::GetBit(cw, 0); uint8_t t_cw1 = BitUtil::GetBit(cw, 1);
            s = BitUtil::XorIf(s_children[path_bit], seed_mask, t);
            uint8_t t_cw_path = (path_bit == 0 ? t_cw0 : t_cw1);
            t = t_children[path_bit] ^ (t_cw_path & t);
        }
        u64 final_val; PRG(s, &final_val, 1);
        return BitUtil::XorIf(final_val, key.final_word, t);
    }

    inline bool EvalFull(const DpfKey& keyA, const DpfKey& keyB, size_t location, u64 value) {
        if (keyA.size != keyB.size) return false;
        for (size_t i = 0; i < keyA.size; ++i) {
            u64 vA = evalDPF(keyA, i); u64 vB = evalDPF(keyB, i); u64 combined = vA ^ vB;
            if (i == location) { if (combined != value) return false; } else { if (combined != 0) return false; }
        }
        return true;
    }
} // namespace DPF



// Configuration parameters
struct Config {
    int m, n, k, q;  // users, items, dimensions, queries
    int party_id;    // 0 or 1 (P2 is dealer only)
    
    Config() : m(0), n(0), k(0), q(0), party_id(0) {}  // No default values, must be set explicitly
};

// Function declarations
void generate_random_matrix(matrix_t& matrix, int rows, int cols);
pair<share_t, share_t> share_secret_2party(share_t secret);
share_t reconstruct_secret_2party(share_t share0, share_t share1);
// One-hot helper functions removed — DPF is used for private selection.

// Beaver protocol functions
BeaverScalarVector generate_beaver_scalar_vector(int vector_size);
BeaverDot generate_beaver_dot(int vector_size);
pair<share_t, vector<share_t>> beaver_scalar_vector_protocol(
    share_t s_share, const vector<share_t>& v_share, 
    const BeaverScalarVector& triple, int party_id);
share_t beaver_dot_protocol(
    const vector<share_t>& u_share, const vector<share_t>& v_share,
    const BeaverDot& triple, int party_id);

// Random number generator
extern mt19937 rng;

// ---------------------- XOR -> ADDITIVE conversion (simulation) ----------------------
// This implements the Python `xor_to_additive_section_d` logic used for
// testing/simulation. It accepts both parties' XOR-share vectors (r0,r1)
// and returns a pair (E0,E1) of additive share vectors.
inline pair<vector<share_t>, vector<share_t>> xor_to_additive_conversion(
    const vector<share_t>& r0, const vector<share_t>& r1) {
    size_t n = r0.size();
    vector<int64_t> t0(n), t1(n);
    for (size_t i = 0; i < n; ++i) {
        t0[i] = static_cast<int64_t>(r0[i]);
        t1[i] = -static_cast<int64_t>(r1[i]);
    }
    int64_t pm = 0;
    for (size_t i = 0; i < n; ++i) pm += t0[i] + t1[i];

    vector<share_t> E0(n), E1(n);
    for (size_t i = 0; i < n; ++i) {
        int64_t e0 = t0[i] * pm;
        int64_t e1 = t1[i] * pm;
        e0 %= static_cast<int64_t>(RING_SIZE_64);
        e1 %= static_cast<int64_t>(RING_SIZE_64);
        if (e0 < 0) e0 += static_cast<int64_t>(RING_SIZE_64);
        if (e1 < 0) e1 += static_cast<int64_t>(RING_SIZE_64);
        E0[i] = static_cast<share_t>(e0);
        E1[i] = static_cast<share_t>(e1);
    }
    return {E0, E1};
}
