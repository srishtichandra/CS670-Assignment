
# MPC Item-Profile Update (Assignment 3 & 4)

This repository contains a simulated two-party MPC protocol that demonstrates a DPF-based private item-profile update and the evaluation framework for timing experiments.

The core update performed for a query mapping user i to item j is:

   v_j ← v_j + u_i * (1 - ⟨u_i, v_j⟩)

where u_i and v_j are k-dimensional vectors, and inner products and multiplications are performed over a finite ring (the implementation uses a 16-bit ring by default).

## Assignment 3 — Updating Item Profiles (protocol overview)

Challenge
- Servers hold additive shares of item profiles and must update the correct item without learning which item was queried.
- The user knows which item j to update, but does not know the update value M = u_i(1−⟨u_i,v_j⟩) since v_j is shared across the servers.

Ideal (infeasible) approach
- If the user knew M, they could generate a DPF carrying M and the servers could locally EvalFull and add the result to their V shares. But the user does not know M, so this is infeasible.

Actual protocol (implemented here)

1. User-side DPF generation
  - User generates a pair of DPF keys that point to the target index i* but carry the value 0:
    (k0, k1) ← Gen(i*, 0)
  - Each key has form kb = (s_b, cw0, ..., cwh, FCW_b) where FCW_b is the final correction word.
  - The user sends k0 to P0 and k1 to P1.

2. Server-side computation of update shares
  - Each server locally computes its share of the update vector M = u_i (1 − ⟨u_i, v_j⟩ ). Denote server shares M0 and M1 such that M = M0 + M1.

3. Adjusting the DPF final correction word
  - Each server replaces its final correction word so that when the two keys are combined, the DPF encodes M (instead of 0) at index i*.
  - To do this the parties exchange masked differences:
     P0 sends (M0 − FCW0),
     P1 sends (M1 − FCW1).
    After exchange both can compute FCW_m = (M0 − FCW0) + (M1 − FCW1) and set their key's final word to FCW_m.

4. Applying the update
  - Each server evaluates its updated DPF key and adds the result to its share of the item profiles:

     V_b ← V_b + EvalFull(k_b)

  - EvalFull produces XOR-based outputs (per-bit). The item profiles are stored as additive shares, so a conversion is required.

Conversion from XOR to Additive shares
1. EvalFull returns XOR shares while V is additive-shared. The implementation includes a demonstration (insecure) conversion that picks a party to negate its vector to convert XOR→additive. This insecure method is acceptable for the assignment demo; a secure conversion (Beaver-based) is optional and will earn bonus points.
2. If you need a cryptographically secure conversion implemented, I can add it (requires additional Beaver triples and an interactive conversion protocol).

Security model and notes
- Secret sharing is additive over a small ring (default 16-bit) in this codebase. The file-based communication simulates synchronous protocols for ease of experimentation.
- The current code includes an insecure XOR→additive conversion (documented above). The rest of the flow follows the DPF-based update design described in Assignment 3.

## Assignment 4 — Evaluation and plotting

Goal: vary the number of queries `q`, items `n`, and users `m` and plot the time taken for one user-profile update and one item-profile update.

What this repo provides for evaluation:
- `run_experiments.sh` — small safe sweep runner (default uses m=10, n=20, k=5, q in [2,10,50,100]).
- `run_sweep_large.sh` — interactive wrapper to run larger sweeps (requires confirmation before running long jobs).
- `generate_graphs.py` — aggregates `runs/*` directories and writes summary plots into `runs/plots/`.
- `plot.py` — small CLI utility to plot per-CSV performance curves.
- `analysis.ipynb` — a notebook with a short report and inline summary plotting cells.

## Quick Start (small test)

1. Build the C++ programs (or use the provided Dockerfile):

```bash
g++ -std=c++17 -O2 gen_beaver.cpp -o gen_beaver
g++ -std=c++17 -O2 gen_queries.cpp -o gen_queries
g++ -std=c++17 -O2 pB.cpp -o pB
```

2. Run the small sweep (safe defaults):

```bash
bash run_experiments.sh
```

3. Generate plots from `runs/`:

```bash
python3 generate_graphs.py --runs runs --outdir runs/plots
```

4. View plots (macOS example):

```bash
open runs/plots/summary_timings.png
```

## Grading and Deliverables (as requested by the assignment)

- Correctness and Security: 80% — the protocol and DPF flow are implemented; the XOR→additive conversion is presently the insecure demo variant (bonus for a secure implementation).
- Code clarity and documentation: 20% — this README, `RUNNING.md`, `analysis.ipynb`, and plotting scripts are included to make the submission navigable and reproducible.

If you want me to run a larger sweep (for example q in [10,50,100,200,500,1000]) and generate final publication-quality plots, tell me the exact (m,n,k) and q list and whether to run on host or inside Docker. I will confirm before starting since large sweeps can be time-consuming.

---
Files of interest:
- `pB.cpp`, `gen_queries.cpp`, `gen_beaver.cpp`, `generate_graphs.py`, `plot.py`, `analysis.ipynb`, `run_experiments.sh`, `run_sweep_large.sh`.



