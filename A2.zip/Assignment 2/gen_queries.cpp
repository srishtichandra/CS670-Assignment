#include <iostream>
#include <vector>
#include <random>
#include <cstdint>
#include <string>
#include <chrono>
#include <utility>
#include <stdexcept>


using u64 = uint64_t;

// -----------------------------------------------------------------------------
// gen_queries.cpp
//
// Single-file submission-ready implementation of a compact-tree Distributed
// Point Function (DPF) generator and verifier for CS670 Assignment 1.
//
// Notation & contracts (simple):
// - generateDPF(size, location, value, rng) -> pair<keyA, keyB>
//     Inputs: domain size `size`, target `location` in [0,size), 64-bit `value`.
//     Output: two compact DPF keys (DpfKey) for parties A and B.
// - evalDPF(key, index) -> u64
//     Inputs: a single DpfKey and an index in [0,size). Returns a 64-bit share.
// - EvalFull(keyA, keyB, location, value) -> bool
//     Exhaustively evaluates both keys across the entire domain and checks
//     that combined outputs (XOR) equal `value` at `location` and 0 elsewhere.
//
// Implementation notes:
// - This is a tree-based construction that stores O(log N) correction words
//   and a final word. Each party holds a root seed and a single one-bit "flag"
//   (previously called "control bit" in earlier drafts). The PRG used here is
//   std::mt19937_64 for determinism in the teaching environment. Replace with a
//   cryptographic PRF (AES/HMAC) for production/cryptographic-grade security.
//
// - The code purposefully keeps compact keys and uses per-level correction
//   words. Each correction word packs a 62-bit seed mask (upper bits) and two
//   flag corrections in the low 2 bits (for left/right child).
//
// - This file is meant to be submission-ready: clear function comments, input
//   validation, and a small command-line driver that runs many random tests.
// -----------------------------------------------------------------------------

// Represents one party's compact DPF key. Its size is logarithmic in the domain size.
struct DpfKey {
    size_t size; // The original domain size
    u64 root_seed; // The starting seed and initial 1-bit flag (LSB)
    std::vector<u64> correction_words; // One correction word per level of the tree
    u64 final_word; // The final correction word to recover the target value
};


// --- Helper Functions ---

// A simple PRG that generates 'count' 64-bit outputs from a given seed.
void PRG(u64 seed, u64* out, size_t count) {
    std::mt19937_64 gen(seed);
    for (size_t i = 0; i < count; ++i) {
        out[i] = gen();
    }
}

namespace BitUtil {
    // Return least-significant bit (flag) of a 64-bit value.
    inline uint8_t LSB(u64 val) { return static_cast<uint8_t>(val & 1ULL); }
    // Clear the lowest two bits (used to separate seed material from packed
    // correction/flag bits). We keep two-bit clearing because correction words
    // reserve the low 2 bits for flag corrections.
    inline u64 ClearLow2(u64 val) { return val & (~3ULL); }
    // Pack two low bits into a 64-bit word while preserving the upper bits.
    inline u64 SetLow2(u64 val, uint8_t b0, uint8_t b1) {
        return ClearLow2(val) | (static_cast<u64>(b0) & 1ULL) | ((static_cast<u64>(b1) & 1ULL) << 1);
    }
    // Extract the bit at bit_idx (0-based, LSB=0).
    inline uint8_t GetBit(u64 val, size_t bit_idx) { return static_cast<uint8_t>((val >> bit_idx) & 1ULL); }
    // Conditionally XOR `s` with `mask` if `condition` is true.
    inline u64 XorIf(u64 s, u64 mask, bool condition) { return condition ? (s ^ mask) : s; }
}

// Calculates the tree depth required for a given domain size.
size_t CalculateDepth(size_t n) {
    if (n <= 1) return n;
    size_t d = 0;
    size_t m = 1;
    while (m < n) {
        m <<= 1;
        ++d;
    }
    return d;
}

// Expand: derive two child seeds and their flags from a parent seed.
// - The PRG produces two 64-bit values. For each child value we treat its
//   LSB as the per-node 1-bit flag and the remaining upper bits as the seed.
// - We then clear the low two bits from the seed portion so that correction
//   words (which reserve low 2 bits) don't collide with seed bits.
void Expand(u64 seed, u64 s_out[2], uint8_t t_out[2]) {
    PRG(seed, s_out, 2);
    t_out[0] = BitUtil::LSB(s_out[0]);
    s_out[0] = BitUtil::ClearLow2(s_out[0]);
    t_out[1] = BitUtil::LSB(s_out[1]);
    s_out[1] = BitUtil::ClearLow2(s_out[1]);
}


// --- Assignment Functions ---

// generateDPF (location, value)
// Generates a pair of compact DPF keys for a given domain size.
std::pair<DpfKey, DpfKey> generateDPF(size_t size, size_t location, u64 value, std::mt19937_64& rng) {
    if (location >= size) throw std::runtime_error("DPF location is out of range.");

    const size_t depth = CalculateDepth(size);

    // Initialize random root seeds for A and B. The LSB is used as a 1-bit flag
    // (call it 't') and the remaining upper bits are the seed material.
    u64 root_seed_A = rng();
    u64 root_seed_B = rng();

    // Ensure the two root flags are opposite: this guarantees one party
    // initially has flag=1 and the other has flag=0.
    uint8_t t_A = BitUtil::LSB(root_seed_A);
    uint8_t t_B = t_A ^ 1;
    // Replace the LSB of root_seed_B with t_B while preserving the upper bits.
    root_seed_B = BitUtil::ClearLow2(root_seed_B) | t_B;

    // Extract seed (upper bits) for both parties by clearing the low 2 bits.
    // The implementation uses only 1 low bit as flag but keeps low-2 clearing
    // for alignment with correction-word packing.
    u64 s_A = BitUtil::ClearLow2(root_seed_A);
    u64 s_B = BitUtil::ClearLow2(root_seed_B);

    // Store one correction word per level. Each correction word packs:
    // [upper 62 bits] = seed_mask (u64) to XOR into a kept child seed when a
    //                    party's flag is 1
    // [bit 0] = flag correction for left child
    // [bit 1] = flag correction for right child
    std::vector<u64> correction_words;
    correction_words.reserve(depth);

    for (size_t i = 0; i < depth; ++i) {
        // Determine which child follows the path to `location` (keep) and
        // which child is the sibling (lose).
        const uint8_t path_bit = BitUtil::GetBit(location, depth - 1 - i);

        // Expand each party's current seed into two child seeds and flags.
        u64 s_A_children[2], s_B_children[2];
        uint8_t t_A_children[2], t_B_children[2];
        Expand(s_A, s_A_children, t_A_children);
        Expand(s_B, s_B_children, t_B_children);

        const uint8_t keep = path_bit;
        const uint8_t lose = 1 - path_bit;

        // Compute the seed-mask correction as XOR of the losing siblings.
        // This mask is used to modify the kept-path seed for the party whose
        // flag is 1 so that outside the path both parties' seeds become equal.
        u64 s_cw = s_A_children[lose] ^ s_B_children[lose];

        // Compute flag corrections for both children so that the invariant
        // (exactly one party has flag=1 on the path) holds.
        uint8_t t_cw[2];
        t_cw[lose] = t_A_children[lose] ^ t_B_children[lose];
        // flip for the keep child so the path's flags diverge correctly
        t_cw[keep] = t_A_children[keep] ^ t_B_children[keep] ^ 1;

        // Update party A and B's state along the kept path. The XorIf applies
        // the seed-mask only when the party's current flag is 1.
        s_A = BitUtil::XorIf(s_A_children[keep], s_cw, t_A);
        t_A = t_A_children[keep] ^ (t_cw[keep] & t_A);

        s_B = BitUtil::XorIf(s_B_children[keep], s_cw, t_B);
        t_B = t_B_children[keep] ^ (t_cw[keep] & t_B);

        // Pack and store correction word for this level.
        u64 cw = BitUtil::SetLow2(s_cw, t_cw[0], t_cw[1]);
        correction_words.push_back(cw);
    }

    // At the leaf, generate each party's final output from its seed. The
    // final correction word is the XOR that makes the combined output equal
    // to the desired `value` at the secret location.
    u64 final_A, final_B;
    PRG(s_A, &final_A, 1);
    PRG(s_B, &final_B, 1);
    u64 final_wc = value ^ final_A ^ final_B;

    DpfKey keyA{size, root_seed_A, correction_words, final_wc};
    DpfKey keyB{size, root_seed_B, correction_words, final_wc};
    
    return {std::move(keyA), std::move(keyB)};
}

// evalDPF (key, index)
// Evaluates a single compact DPF key at a given index.
u64 evalDPF(const DpfKey& key, size_t index) {
    if (index >= key.size) throw std::runtime_error("DPF index is out of range.");
    
    const size_t d = CalculateDepth(key.size);
    u64 s = BitUtil::ClearLow2(key.root_seed);
    uint8_t t = BitUtil::LSB(key.root_seed);

    // Walk down the tree from root to leaf. At each level we expand our
    // current seed into children and follow the branch indicated by `index`.
    // If our per-node flag `t` is 1, we apply the seed-mask from the
    // correction word to the chosen child seed. Then we update `t` according
    // to the child flag and the correction-bit packed for that child.
    for (size_t i = 0; i < d; ++i) {
        const u64& cw = key.correction_words[i];
        const uint8_t path_bit = BitUtil::GetBit(index, d - 1 - i);

        u64 s_children[2];
        uint8_t t_children[2];
        Expand(s, s_children, t_children);

    // Unpack the correction word: the upper bits are a seed mask (to xor)
    // and the low two bits are the flag corrections for left/right child.
        u64 seed_mask = BitUtil::ClearLow2(cw);
        uint8_t t_cw0 = BitUtil::GetBit(cw, 0);
        uint8_t t_cw1 = BitUtil::GetBit(cw, 1);

    // If our current flag t is 1 then apply the seed_mask to the chosen
    // child seed; otherwise leave the child seed unchanged. This is the
    // key conditional correction that ensures the two parties' seeds
    // become identical off the secret path.
        s = BitUtil::XorIf(s_children[path_bit], seed_mask, t);

        // Update the flag for the next level: the child's flag is XORed with
        // the correction-bit only if our current flag was set. This preserves
        // the invariant that on the secret path exactly one party has flag=1.
        uint8_t t_cw_path = (path_bit == 0 ? t_cw0 : t_cw1);
        t = t_children[path_bit] ^ (t_cw_path & t);
    }

    u64 final_val;
    PRG(s, &final_val, 1);
    // If our final flag is 1 then apply the final correction word so that the
    // two parties' final outputs combine to `value` at the target location.
    return BitUtil::XorIf(final_val, key.final_word, t);
}


// EvalFull (key, size)
// Evaluates and verifies the DPF across the entire domain.
bool EvalFull(const DpfKey& keyA, const DpfKey& keyB, size_t location, u64 value) {
    if (keyA.size != keyB.size) {
        std::cerr << "FAIL: Key sizes do not match.\n";
        return false;
    }
    for (size_t i = 0; i < keyA.size; ++i) {
        u64 vA = evalDPF(keyA, i);
        u64 vB = evalDPF(keyB, i);
        u64 combined = vA ^ vB;

        if (i == location) {
            if (combined != value) {
                std::cerr << "FAIL at location " << i << ": combined value " << combined
                          << " != expected " << value << std::endl;
                return false;
            }
        } else {
            if (combined != 0) {
                std::cerr << "FAIL at non-location " << i << ": combined value "
                          << combined << " != 0" << std::endl;
                return false;
            }
        }
    }
    return true;
}

// --- Main Program Logic ---

static std::string usage(const char* prog) {
    return std::string("Usage: ") + prog + " <DPF_size> <num_DPFs>\n"
           + "Example: " + prog + " 1024 10\n";
}

int main(int argc, char** argv) {
    if (argc != 3) {
        std::cerr << usage(argv[0]);
        return 1;
    }

    size_t dpf_size = 0;
    try {
        dpf_size = std::stoull(argv[1]);
    } catch (...) {
        std::cerr << "Invalid DPF_size\n";
        return 1;
    }

    int num_dpfs = 0;
    try {
        num_dpfs = std::stoi(argv[2]);
    } catch (...) {
        std::cerr << "Invalid num_DPFs\n";
        return 1;
    }

    if (dpf_size == 0 || num_dpfs <= 0) {
        std::cerr << "DPF_size must be > 0 and num_DPFs must be > 0\n";
        return 1;
    }

    std::random_device rd;
    u64 seed = (static_cast<u64>(rd()) << 32) ^ static_cast<u64>(rd()) ^
               static_cast<u64>(std::chrono::high_resolution_clock::now().time_since_epoch().count());
    std::mt19937_64 rng(seed);

    std::uniform_int_distribution<size_t> idx_dist(0, dpf_size - 1);
    std::uniform_int_distribution<u64> val_dist;

    for (int inst = 0; inst < num_dpfs; ++inst) {
        size_t location = idx_dist(rng);
        u64 value = val_dist(rng);

        auto keys = generateDPF(dpf_size, location, value, rng);
        const DpfKey& kA = keys.first;
        const DpfKey& kB = keys.second;

        std::cout << "Instance " << inst << ": location=" << location << " value=0x"
                  << std::hex << value << std::dec;

        bool ok = EvalFull(kA, kB, location, value);

        std::cout << " => " << (ok ? "Test Passed" : "Test Failed") << "\n";

        if (!ok) {
            std::cerr << "Verification failed for instance " << inst << ". Aborting.\n";
            return 2;
        }
    }

    std::cout << "\nAll " << num_dpfs << " instances passed verification.\n";
    return 0;
}

