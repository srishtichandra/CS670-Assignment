Distributed Point Function (DPF) Generator — CS670 Assignment 1
================================================================

This zip contains `gen_queries.cpp`, a single-file, submission-ready C++ implementation of a compact Distributed Point Function (DPF). The program generates two compact keys for a secret point `(location, value)` and verifies correctness across the entire domain.

Why a DPF?
----------
A DPF lets two non-colluding servers hold small keys such that:

- For the secret index `alpha` the XOR of their evaluations equals a secret value `beta`.
- For any other index `x != alpha` the XOR of evaluations equals zero.

This is useful for private information retrieval, distributed aggregation, and secure multiparty protocols where large private arrays would otherwise be needed.

Implementation
-----------------------------------
- Construction: tree-based compact DPF (O(log N) key size). Keys contain a root seed, a vector of per-level correction words, and a final correction word.
- PRG: `std::mt19937_64` seeded per-node . 
- Interface functions implemented in `gen_queries.cpp`:
  - `generateDPF(size, location, value, rng)` -> pair of keys
  - `evalDPF(key, index)` -> 64-bit share
  - `EvalFull(keyA, keyB, location, value)` -> bool (verifies XOR correctness across the domain)


Build
-----
Requires a C++17-compatible compiler (g++ on macOS / Linux). From the project root:

```bash
g++ -std=c++17 -O2 gen_queries.cpp -o gen_queries
```

Usage
-----
Run the program with two arguments:

```bash
./gen_queries <DPF_size> <num_DPFs>
```

- `<DPF_size>`: number of indices in the domain (N). Must be > 0.
- `<num_DPFs>`: how many random DPF instances to generate and verify.

Example:

```bash
./gen_queries 1024 10
```

For each instance the program prints the chosen `location` and `value` and whether the `EvalFull` verification passed.

Detailed algorithm 
--------------------------------
This implementation uses a binary tree of depth `d = ceil(log2(N))` whose leaves correspond to indices `0..N-1`.

1. Key generation (generateDPF):
   - Create two random 64-bit root seeds, one for each party. The least-significant bit (LSB) of each seed is a 1-bit "flag" and the remaining upper bits are the seed material.
   - Force the two root flags to be opposite (one party has flag=1, the other flag=0). This ensures only one party remains "active" on the secret path.
   - For each level of the tree (from root to leaf):
     - Expand each party's current seed with a PRG into two child seeds and two child flags.
     - Identify the child that follows the secret path and the sibling .
     - Compute a seed-mask equal to XOR of the two losing-sibling seeds. This mask will be applied conditionally by the party with flag=1.
     - Compute two flag-corrections (for left/right). These bits ensure the invariant that on the secret path exactly one party's flag remains 1.
     - Update each party's seed/flag for the next level: the party with flag=1 xors its kept-child seed with the seed-mask; both parties update their flags using the PRG-derived child flags and correction bits.
     - Store the packed correction word (seed-mask in upper bits, two flag-corrections in low 2 bits).
   - At the leaf, derive each party's final output from its seed using the PRG; compute the final correction word so the XOR of final outputs equals `value` at the secret location.

2. Evaluation (evalDPF):
   - Start from the root seed and its LSB flag.
   - For each level follow the index bit for that level, expand the current seed to children, and choose the child seed/flag.
   - If your current flag is 1, XOR the chosen child seed with the seed-mask from the correction word.
   - Update the flag using the child's flag and the packed correction-bit for that child.
   - At the leaf generate the final value; if your final flag is 1, apply the final correction word.

3. Verification (EvalFull):
   - Exhaustively evaluate both keys at every index 0..N-1 and verify that their XOR equals `value` at the chosen `location` and 0 at every other index.

Complexity and sizes
--------------------
- Key size: O(d) correction words + a root seed + one final word, where d = ceil(log2(N)).
- Generation time: O(d) PRG expansions.
- Evaluation time per index: O(d) PRG expansions.

Reproducibility
---------------
The program seeds its RNG nondeterministically (using `std::random_device` plus a time-derived value). 