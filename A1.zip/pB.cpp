#include "common.hpp"
#include <thread>
#include <chrono>

// Helper to load a matrix of shares from a file
void load_matrix_shares(const string& filename, matrix_t& matrix, int rows) {
    ifstream file(filename);
    string line;
    getline(file, line); getline(file, line); // Skip headers
    matrix.resize(rows);
    for (int i = 0; i < rows; ++i) {
        getline(file, line);
        istringstream iss(line);
        share_t val;
        while (iss >> val) matrix[i].push_back(val);
    }
}

// Simulate communication by writing differences to a file
void exchange_diffs(const string& filename, const vector<vector<share_t>>& diffs) {
    ofstream out(filename);
    for (const auto& row : diffs) {
        for (size_t i = 0; i < row.size(); ++i) {
            out << row[i] << (i == row.size() - 1 ? "" : " ");
        }
        out << endl;
    }
}

// Simulate receiving data by reading from a file
void wait_and_reconstruct_diffs(const string& filename, vector<vector<share_t>>& our_diffs) {
    while (!ifstream(filename).good()) {
        this_thread::sleep_for(chrono::milliseconds(20));
    }
    ifstream in(filename);
    string line;
    int row_idx = 0;
    while (getline(in, line)) {
        istringstream iss(line);
        share_t val;
        int col_idx = 0;
        while (iss >> val) {
            our_diffs[row_idx][col_idx] += val; // Reconstruct by adding shares
            col_idx++;
        }
        row_idx++;
    }
}

// Secure Multiplication of a secret scalar [x] and secret vector [y]
// Returns shares of [x*y]
vector<share_t> secure_scalar_vec_mult(share_t x_share, const vector<share_t>& y_share,
                                       share_t a_share, const vector<share_t>& b_share,
                                       const vector<share_t>& c_share,
                                       int party_id, int k, const string& comm_prefix) {
    // 1. Compute differences locally
    share_t d = x_share - a_share;
    vector<share_t> e = y_share;
    for (int i = 0; i < k; ++i) e[i] -= b_share[i];

    // 2. Exchange and reconstruct
    string fname = comm_prefix + to_string(party_id) + ".txt";
    string other_fname = comm_prefix + to_string(1 - party_id) + ".txt";
    vector<vector<share_t>> diffs = {{d}, e};
    exchange_diffs(fname, diffs);
    wait_and_reconstruct_diffs(other_fname, diffs);
    share_t D = diffs[0][0];
    vector<share_t> E = diffs[1];

    // 3. Compute final shares
    vector<share_t> z_share = c_share;
    for (int i = 0; i < k; ++i) {
        z_share[i] += a_share * E[i];
        z_share[i] += D * b_share[i];
        // CORRECTED: Only one party (P0) adds the public cross-term
        if (party_id == 0) {
            z_share[i] += D * E[i];
        }
    }
    return z_share;
}

// Secure Dot Product of two secret vectors [x] and [y]
// Returns a share of [x·y]
share_t secure_dot_product(const vector<share_t>& x_share, const vector<share_t>& y_share,
                           const vector<share_t>& a_share, const vector<share_t>& b_share,
                           share_t c_share, int party_id, int k, const string& comm_prefix) {
    // 1. Compute differences locally
    vector<share_t> d = x_share, e = y_share;
    for(int i=0; i<k; ++i) d[i] -= a_share[i];
    for(int i=0; i<k; ++i) e[i] -= b_share[i];

    // 2. Exchange and reconstruct
    string fname = comm_prefix + to_string(party_id) + ".txt";
    string other_fname = comm_prefix + to_string(1 - party_id) + ".txt";
    vector<vector<share_t>> diffs = {d, e};
    exchange_diffs(fname, diffs);
    wait_and_reconstruct_diffs(other_fname, diffs);
    vector<share_t> D = diffs[0], E = diffs[1];

    // 3. Compute final share
    share_t z_share = c_share;
    uint64_t cross_term = 0;
    for(int i=0; i<k; ++i) {
        z_share += a_share[i] * E[i];
        z_share += D[i] * b_share[i];
        cross_term += (uint64_t)D[i] * E[i];
    }
    // CORRECTED: Only one party (P0) adds the public cross-term
    if (party_id == 0) {
        z_share += cross_term;
    }
    return z_share;
}


int main(int argc, char* argv[]) {
    if (argc != 6) {
        cerr << "Usage: " << argv[0] << " <party_id> <m> <n> <k> <q>" << endl;
        return 1;
    }

    Config config;
    config.party_id = stoi(argv[1]);
    config.m = stoi(argv[2]);
    config.n = stoi(argv[3]);
    config.k = stoi(argv[4]);
    config.q = stoi(argv[5]);
    
    // --- LOAD ALL DATA ---
    cout << "P" << config.party_id << ": Loading data..." << endl;
    string prefix = "p" + to_string(config.party_id);
    
    matrix_t u_shares, v_shares, j_shares;
    load_matrix_shares(prefix + "_u_shares.txt", u_shares, config.m);
    load_matrix_shares(prefix + "_v_shares.txt", v_shares, config.n);
    load_matrix_shares(prefix + "_j_shares.txt", j_shares, config.q);

    matrix_t sv_a(config.n + config.q), sv_b(config.n + config.q), sv_c(config.n + config.q);
    ifstream sv_file(prefix + "_scalar_vector_triples.txt");
    string line;
    getline(sv_file, line); getline(sv_file, line); getline(sv_file, line);
    for(int i=0; i<(config.n + config.q); ++i) {
        sv_a[i].resize(1); sv_b[i].resize(config.k); sv_c[i].resize(config.k);
        sv_file >> sv_a[i][0];
        for(int l=0; l<config.k; ++l) sv_file >> sv_b[i][l];
        for(int l=0; l<config.k; ++l) sv_file >> sv_c[i][l];
    }

    vector<share_t> dot_a, dot_b;
    share_t dot_c;
    ifstream dot_file(prefix + "_dot_triple.txt");
    getline(dot_file, line); getline(dot_file, line);
    dot_a.resize(config.k); dot_b.resize(config.k);
    for(int l=0; l<config.k; ++l) dot_file >> dot_a[l];
    for(int l=0; l<config.k; ++l) dot_file >> dot_b[l];
    dot_file >> dot_c;
    
    vector<QueryMetadata> queries(config.q);
    ifstream meta_file("query_metadata.txt");
    getline(meta_file, line); getline(meta_file, line); getline(meta_file, line);
    for(int i=0; i<config.q; ++i) {
        meta_file >> queries[i].query_id >> queries[i].user_id >> queries[i].item_j;
    }
    
    cout << "P" << config.party_id << ": Starting online protocol..." << endl;

    // --- ONLINE PROTOCOL ---
    for (int i = 0; i < config.q; ++i) {
        cout << "\nP" << config.party_id << ": --- Query " << i << " ---" << endl;
        int user_idx = queries[i].user_id;

        // 1. Oblivious Selection: Compute shares of v_j = Σ (sel_k * v_k)
        vector<share_t> v_j_share(config.k, 0);
        for (int k = 0; k < config.n; ++k) {
            string comm_prefix = "comm_select_q" + to_string(i) + "_k" + to_string(k) + "_p";
            vector<share_t> term = secure_scalar_vec_mult(j_shares[i][k], v_shares[k],
                sv_a[k][0], sv_b[k], sv_c[k], config.party_id, config.k, comm_prefix);
            for(int l=0; l<config.k; ++l) v_j_share[l] += term[l];
        }

        // 2. Secure Dot Product: Compute share of s = <u_i, v_j>
        string comm_dot_prefix = "comm_dot_q" + to_string(i) + "_p";
        share_t s_share = secure_dot_product(u_shares[user_idx], v_j_share,
            dot_a, dot_b, dot_c, config.party_id, config.k, comm_dot_prefix);
        
        // 3. Secure Update: Compute u_i <- u_i + (1-s) * v_j
        share_t delta_share = (config.party_id == 0) ? (1 - s_share) : (0 - s_share);
        
        string comm_update_prefix = "comm_update_q" + to_string(i) + "_p";
        // Use dedicated Beaver triple for update (n+i to avoid conflict with selection)
        int update_triple_idx = config.n + i;
        vector<share_t> update_term = secure_scalar_vec_mult(delta_share, v_j_share,
            sv_a[update_triple_idx][0], sv_b[update_triple_idx], sv_c[update_triple_idx], config.party_id, config.k, comm_update_prefix);
        
        for (int l = 0; l < config.k; ++l) {
            u_shares[user_idx][l] += update_term[l];
        }
        cout << "P" << config.party_id << ": Query " << i << " processed." << endl;
    }

    // --- PRINT FINAL RESULTS ---
    cout << "\n=== P" << config.party_id << ": Final Updated U Shares ===" << endl;
    for (int i = 0; i < config.m; ++i) {
        cout << "User " << i << ": ";
        for (int d = 0; d < config.k; ++d) {
            cout << u_shares[i][d];
            if (d < config.k - 1) cout << " ";
        }
        cout << endl;
    }
    
    // --- DEBUGGING COMMUNICATION: P1 sends shares to P0 for reconstruction ---
    if (config.party_id == 1) {
        // P1 writes its final shares to a file for P0 to read
        cout << "\nP1: Sending final shares to P0 for debugging..." << endl;
        ofstream debug_file("debug_p1_final_shares.txt");
        for (int i = 0; i < config.m; ++i) {
            for (int d = 0; d < config.k; ++d) {
                debug_file << u_shares[i][d];
                if (d < config.k - 1) debug_file << " ";
            }
            debug_file << endl;
        }
        debug_file.close();
        cout << "P1: Final shares sent to P0." << endl;
    } else {
        // P0 waits for P1's shares and reconstructs for verification
        cout << "\nP0: Waiting for P1's final shares for debugging..." << endl;
        
        // Wait for P1's file
        while (!ifstream("debug_p1_final_shares.txt").good()) {
            this_thread::sleep_for(chrono::milliseconds(50));
        }
        
        // Read P1's shares
        matrix_t p1_final_shares;
        ifstream debug_file("debug_p1_final_shares.txt");
        string line;
        p1_final_shares.resize(config.m);
        for (int i = 0; i < config.m; ++i) {
            getline(debug_file, line);
            istringstream iss(line);
            share_t val;
            while (iss >> val) {
                p1_final_shares[i].push_back(val);
            }
        }
        debug_file.close();
        
        // Reconstruct and print final U matrix
        cout << "\n=== P0: RECONSTRUCTED FINAL U MATRIX (for debugging only) ===" << endl;
        for (int i = 0; i < config.m; ++i) {
            cout << "User " << i << ": ";
            for (int d = 0; d < config.k; ++d) {
                share_t p0_share = u_shares[i][d];
                share_t p1_share = p1_final_shares[i][d];
                uint64_t sum = (uint64_t)p0_share + (uint64_t)p1_share;
                share_t reconstructed = sum % RING_SIZE_64;
                cout << reconstructed;
                if (d < config.k - 1) cout << " ";
                // Debug: print the calculation
                cout << " [" << p0_share << "+" << p1_share << "=" << sum << " mod " << RING_SIZE_64 << "=" << reconstructed << "]";
            }
            cout << endl;
        }
        
        // Clean up debug file
        remove("debug_p1_final_shares.txt");
    }
    
    cout << "\n✅ P" << config.party_id << ": Protocol finished." << endl;

    return 0;
}