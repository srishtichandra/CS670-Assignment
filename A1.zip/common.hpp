#pragma once

#include <vector>
#include <random>
#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <iomanip>

using namespace std;

// Type definitions - using 16-bit for mod 2^16 arithmetic (smaller ring for easier verification)
using share_t = uint32_t;  // Still use uint32_t to avoid overflow during calculations
using matrix_t = vector<vector<share_t>>;

// Ring size for mod 2^16 arithmetic (much smaller for easier manual verification)
const int RING_BITS = 16;
const uint64_t RING_SIZE_64 = (1ULL << RING_BITS);  // 2^16 = 65536
const share_t MAX_VALUE = 1000;  // Keep values reasonable for smaller ring

// Query Metadata for verification
struct QueryMetadata {
    int query_id;
    int user_id;
    int item_j;
};

// Party roles (S0 and S1 as per assignment)
enum PartyRole {
    S0 = 0,
    S1 = 1
};

// 2-party secret share structure (for P0 and P1 only)
struct SecretShare {
    share_t share;
    int party_id;  // 0 or 1
};

// One-hot vector for private index j
struct OneHotVector {
    vector<share_t> sel;  // sel[j] = 1, others = 0
    int true_index;       // actual j (only known to querier)
    
    OneHotVector() : sel(), true_index(-1) {}  // Default constructor
    OneHotVector(int size) : sel(size, 0), true_index(-1) {}
};

// Beaver scalar×vector triple
struct BeaverScalarVector {
    share_t a_scalar;         // scalar share
    vector<share_t> b_vector; // vector share
    vector<share_t> c_vector; // c = a * b share
};

// Beaver dot-product triple  
struct BeaverDot {
    vector<share_t> a, b;     // vector shares
    share_t c;                // c = dot(a,b) share
};

// Query structure
struct Query {
    int i, j;  // user index i, item index j
    vector<share_t> u_i;      // shares of u_i vector
    OneHotVector sel_j;       // one-hot vector for j
    
    Query() : i(0), j(0), sel_j(1) {}  // Default constructor
    Query(int size) : i(0), j(0), sel_j(size) {}  // Constructor with size
};

// Configuration parameters
struct Config {
    int m, n, k, q;  // users, items, dimensions, queries
    int party_id;    // 0 or 1 (P2 is dealer only)
    
    Config() : m(0), n(0), k(0), q(0), party_id(0) {}  // No default values, must be set explicitly
};

// Function declarations
void generate_random_matrix(matrix_t& matrix, int rows, int cols);
pair<share_t, share_t> share_secret_2party(share_t secret);
share_t reconstruct_secret_2party(share_t share0, share_t share1);
OneHotVector create_one_hot_vector(int j, int size);
pair<OneHotVector, OneHotVector> share_one_hot_vector(const OneHotVector& sel);

// Beaver protocol functions
BeaverScalarVector generate_beaver_scalar_vector(int vector_size);
BeaverDot generate_beaver_dot(int vector_size);
pair<share_t, vector<share_t>> beaver_scalar_vector_protocol(
    share_t s_share, const vector<share_t>& v_share, 
    const BeaverScalarVector& triple, int party_id);
share_t beaver_dot_protocol(
    const vector<share_t>& u_share, const vector<share_t>& v_share,
    const BeaverDot& triple, int party_id);

// Random number generator
extern mt19937 rng;
