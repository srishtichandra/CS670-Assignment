# Secure Multi-Party Computation (MPC) for Private Assignment Updates

This repository implements a **cryptographically secure 2-party computation protocol** for private assignment updates using the formula: **ui ← ui + vj(1 - ⟨ui,vj⟩)**

## 🎯 What This Implementation Does

The protocol allows two parties to securely compute assignment updates on user vectors without revealing:
- The original user/item vectors
- Which items are being queried  
- Intermediate computation results

**Only the final updated user vectors are reconstructed** (and only for verification purposes in this implementation).

## 📁 File Structure

```
├── common.hpp          # Shared data structures, constants, and type definitions
├── gen_queries.cpp     # Generates test data and secret shares
├── gen_beaver.cpp      # Generates Beaver triples for secure multiplication  
├── pB.cpp             # Main MPC protocol implementation
├── verify.cpp         # Manual verification program
└── README.md          # This documentation
```

## ⚡ Quick Start - Docker Workflow (RECOMMENDED)

The simplest way to run the complete protocol:

```bash
# Build the Docker container with all dependencies
docker-compose build

# Run the complete MPC protocol workflow  
docker-compose up
```

That's it! This will automatically:
1. Compile all programs
2. Generate test data and secret shares
3. Generate cryptographic Beaver triples  
4. Run the secure 2-party computation
5. Verify the results

## 🔧 Manual Workflow (Alternative)

If you prefer to run without Docker:
```bash
# 1. Compile all programs
g++ -o gen_queries gen_queries.cpp
g++ -o gen_beaver gen_beaver.cpp  
g++ -o pB pB.cpp


# 2. Generate test data and shares (3 users, 2 items, 2 features, 2 queries)
./gen_queries 3 2 2 2

# 3. Generate cryptographic Beaver triples
./gen_beaver 3 2 2 2

# 4. Run the secure MPC protocol (both parties in parallel)
./pB 0 3 2 2 2 & ./pB 1 3 2 2 2 & wait


```

## 🔧 Detailed Usage

### Step 1: Data Generation
```bash
./gen_queries <m> <n> <k> <q>
```
- `m`: number of users  
- `n`: number of items
- `k`: feature vector dimension
- `q`: number of queries

**Creates:**
- `p0_u_shares.txt`, `p1_u_shares.txt` - Secret shares of user vectors
- `p0_v_shares.txt`, `p1_v_shares.txt` - Secret shares of item vectors
- `p0_j_shares.txt`, `p1_j_shares.txt` - Secret shares of selection vectors
- `query_metadata.txt` - Query information (user_id → item_id mappings)

### Step 2: Beaver Triple Generation  
```bash
./gen_beaver <m> <n> <k> <q>
```
**Creates:**
- `p0_scalar_vector_triples.txt`, `p1_scalar_vector_triples.txt` - For scalar×vector multiplications
- `p0_dot_triple.txt`, `p1_dot_triple.txt` - For secure dot products

### Step 3: MPC Protocol Execution
```bash
./pB <party_id> <m> <n> <k> <q>
```
- `party_id`: 0 or 1 (which party this instance represents)
- Must run both parties: `./pB 0 ... & ./pB 1 ... & wait`

## 🧮 Mathematical Foundation

### Assignment Formula
For each query mapping user `i` to item `j`:
```
ui ← ui + vj(1 - ⟨ui,vj⟩)
```

### Secure Computation Steps
1. **Oblivious Selection**: Securely compute `vj = Σ(selection_bit_k × vk)` 
2. **Secure Dot Product**: Compute `s = ⟨ui,vj⟩` without revealing vectors
3. **Assignment Update**: Compute `ui ← ui + vj(1-s)` securely

### Cryptographic Security
- **Secret Sharing**: Additive shares over ring Z₂¹⁶ (mod 65536)
- **Beaver Triples**: Each multiplication uses fresh cryptographic randomness  
- **Semi-Honest Security**: Secure against parties that follow protocol but try to learn information

## 📊 Example Output

When you run the complete workflow, you'll see:

```
=== CONFIGURATION ===
m=3 n=2 k=2 q=2
Ring: Z_{2^16} (size=65536)

=== P0 SHARES ===
U shares (P0):
  User 0: 47191 60788
  User 1: 44131 60263
  User 2: 16023 41090
...

P0: Starting online protocol...
P0: --- Query 0 ---
P0: Query 0 processed.
P0: --- Query 1 ---  
P0: Query 1 processed.

=== P0: RECONSTRUCTED FINAL U MATRIX ===
User 0: 542 67
User 1: 59064 5530    
User 2: 7862 32731
✅ P0: Protocol finished.
```

